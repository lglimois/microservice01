/**
 * Spring Security configuration.
 */
package fr.sh.portailti.security;
