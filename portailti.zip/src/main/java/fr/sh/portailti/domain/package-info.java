/**
 * JPA domain objects.
 */
package fr.sh.portailti.domain;
