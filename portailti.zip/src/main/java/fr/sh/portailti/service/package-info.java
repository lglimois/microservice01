/**
 * Service layer beans.
 */
package fr.sh.portailti.service;
