/**
 * Data Transfer Objects.
 */
package fr.sh.portailti.service.dto;
