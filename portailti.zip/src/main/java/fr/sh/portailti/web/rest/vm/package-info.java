/**
 * View Models used by Spring MVC REST controllers.
 */
package fr.sh.portailti.web.rest.vm;
