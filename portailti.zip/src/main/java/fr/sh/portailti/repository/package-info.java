/**
 * Spring Data JPA repositories.
 */
package fr.sh.portailti.repository;
