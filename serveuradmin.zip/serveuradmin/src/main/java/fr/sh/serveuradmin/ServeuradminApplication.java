package fr.sh.serveuradmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServeuradminApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServeuradminApplication.class, args);
	}

}
